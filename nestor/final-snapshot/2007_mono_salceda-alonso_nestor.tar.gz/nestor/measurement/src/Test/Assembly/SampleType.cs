using System;

namespace Test.Assembly {
	public class SampleType {
		public void MethodWithoutParameters () 
		{
		}

		public void MethodWithOneParameter (int x) 
		{
		}

		public void MethodWithTwoParameters (int x, char j) 
		{
		}

		public void MethodWithThreeParameters (int x, char j, string z) 
		{
		}

		public void OverloadedMethod (int x, char z) 
		{
		}

		public void OverloadedMethod (int x, char z, float f)
		{
		}
	}
}
